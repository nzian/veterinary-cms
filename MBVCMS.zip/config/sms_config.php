<?php
// PhilSMS Configuration
define('PHILSMS_API_KEY', 'your_philsms_api_key_here');
define('PHILSMS_SENDER_ID', 'YourClinic'); // Your clinic name

// Database configuration (if not already defined)
// define('DB_HOST', 'localhost');
// define('DB_NAME', 'your_database');
// define('DB_USER', 'your_username');
// define('DB_PASS', 'your_password');
?>