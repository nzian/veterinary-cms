

<?php $__env->startSection('content'); ?>
<head>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <style>
    /* Modern animations and effects */
    .fade-in {
      animation: fadeIn 0.3s ease-in-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .slide-in {
      animation: slideIn 0.5s ease-out;
    }
    
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    /* Modern glassmorphism effect */
    .glass-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.3);
    }
    
    /* Modern button hover effects */
    .modern-btn {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }
    
    .modern-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    }
    
    .modern-btn::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transition: left 0.5s;
    }
    
    .modern-btn:hover::before {
      left: 100%;
    }
    
    /* Product grid hover effects */
    .product-card {
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }
    
    .product-card:hover {
      transform: translateY(-4px) scale(1.02);
      box-shadow: 0 15px 35px rgba(15, 126, 160, 0.2);
    }
    
    .product-card::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(135deg, rgba(15, 126, 160, 0.1), rgba(15, 126, 160, 0.05));
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    
    .product-card:hover::after {
      opacity: 1;
    }
    
    /* Quantity input animations */
    .qty-control {
      transition: all 0.2s ease;
    }
    
    .qty-control:hover {
      background: #0f7ea0;
      color: white;
      transform: scale(1.1);
    }
    
    /* Modern scrollbar */
    .custom-scrollbar::-webkit-scrollbar {
      width: 6px;
    }
    
    .custom-scrollbar::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 10px;
    }
    
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: linear-gradient(135deg, #0f7ea0, #0c6b87);
      border-radius: 10px;
    }
    
    .custom-scrollbar::-webkit-scrollbar-thumb:hover {
      background: linear-gradient(135deg, #0c6b87, #0a5a73);
    }
    
    /* Ripple effect */
    .ripple {
      position: relative;
      overflow: hidden;
    }
    
    .ripple::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.5);
      transform: translate(-50%, -50%);
      transition: width 0.6s, height 0.6s;
    }
    
    .ripple:active::before {
      width: 300px;
      height: 300px;
    }
  </style>
</head>

<div class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
  <div class="max-w-7xl mx-auto">
    
    <!-- Header Section -->
    <div class="glass-card rounded-2xl p-6 mb-6 shadow-xl">
      <div class="flex items-center justify-between mb-4">
        <div class="flex items-center gap-4">
          <div class="w-12 h-12 bg-gradient-to-br from-[#0f7ea0] to-[#0c6b87] rounded-xl flex items-center justify-center shadow-lg">
            <i class="fas fa-cash-register text-white text-xl"></i>
          </div>
          <div>
            <h1 class="text-2xl font-bold text-gray-800">Point of Sale</h1>
            <p class="text-sm text-gray-500">Manage transactions and sales</p>
          </div>
        </div>
        <div class="flex items-center gap-3">
          <div class="px-4 py-2 bg-green-100 text-green-800 rounded-xl font-medium text-sm">
            <i class="fas fa-circle text-green-500 mr-2 animate-pulse"></i>
            System Online
          </div>
        </div>
      </div>
      
      <!-- Pet Owner Selection -->
      <div class="bg-white/70 rounded-xl p-4 border border-white/50">
        <label for="petOwner" class="block text-sm font-semibold text-gray-700 mb-2">
          <i class="fas fa-user mr-2 text-[#0f7ea0]"></i>
          Select Pet Owner
        </label>
        <select id="petOwner" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#0f7ea0] focus:border-transparent transition-all duration-300 bg-white shadow-sm">
          <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($owner->own_id); ?>"><?php echo e($owner->own_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      <!-- Cart Section (Left) -->
      <div class="lg:col-span-2">
        <div class="glass-card rounded-2xl shadow-xl overflow-hidden">
          <!-- Cart Header -->
          <div class="bg-gradient-to-r from-[#0f7ea0] to-[#0c6b87] text-white p-6">
            <h2 class="text-xl font-bold flex items-center gap-3">
              <i class="fas fa-shopping-cart"></i>
              Shopping Cart
            </h2>
          </div>
          
          <!-- Cart Items Header -->
          <div class="bg-gray-50 border-b border-gray-200">
            <div class="grid grid-cols-[50px_1fr_120px_100px_120px_60px] items-center text-center py-4 font-semibold text-gray-700 text-sm">
              <div>#</div>
              <div class="text-left">Item</div>
              <div>Quantity</div>
              <div>Price</div>
              <div>Total</div>
              <div>Action</div>
            </div>
          </div>

          <!-- Cart Items Container -->
          <div id="posItems" class="custom-scrollbar max-h-96 overflow-y-auto bg-white"></div>

          <!-- Cart Footer -->
          <div class="bg-gray-50 border-t border-gray-200 p-4">
            <div class="flex justify-between items-center mb-4">
              <div class="text-lg font-semibold text-gray-700">
                Total Items: <span id="totalQty" class="text-[#0f7ea0]">0</span>
              </div>
              <div class="text-2xl font-bold text-gray-800">
                Total: <span id="grandTotal" class="text-[#0f7ea0]">₱0.00</span>
              </div>
            </div>
            
            <div class="flex gap-3 justify-end">
              <button id="printReceipt" class="modern-btn ripple px-6 py-3 bg-gray-600 text-white rounded-xl font-semibold shadow-lg hover:bg-gray-700 flex items-center gap-2">
                <i class="fas fa-print"></i>
                Print Receipt
              </button>
              <button id="payNow" class="modern-btn ripple px-8 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-semibold shadow-lg hover:from-green-600 hover:to-green-700 flex items-center gap-2">
                <i class="fas fa-credit-card"></i>
                Pay Now
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Products Section (Right) -->
      <div class="lg:col-span-1">
        <div class="glass-card rounded-2xl shadow-xl overflow-hidden">
          <!-- Products Header -->
          <div class="bg-gradient-to-r from-[#0f7ea0] to-[#0c6b87] text-white p-6">
            <h2 class="text-xl font-bold flex items-center gap-3 mb-4">
              <i class="fas fa-box-open"></i>
              Products & Services
            </h2>
            
            <!-- Search Bar -->
            <div class="relative">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i class="fas fa-search text-white/70"></i>
              </div>
              <input type="search" id="searchItem" placeholder="Search items..." 
                     class="w-full pl-10 pr-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-xl text-white placeholder-white/70 focus:bg-white/30 focus:border-white/50 transition-all duration-300" />
            </div>
          </div>

          <!-- Products Grid -->
          <div id="productContainer" class="p-4 grid grid-cols-1 gap-3 custom-scrollbar max-h-96 overflow-y-auto bg-white">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <button type="button"
                class="product-card product-btn bg-white border-2 border-gray-100 rounded-xl p-4 text-left hover:border-[#0f7ea0] transition-all duration-300 shadow-sm"
                data-id="<?php echo e($item->id); ?>"
                data-name="<?php echo e($item->name); ?>"
                data-price="<?php echo e($item->price); ?>"
                data-type="<?php echo e($item->type); ?>">
                <div class="flex items-center justify-between">
                  <div>
                    <h4 class="font-semibold text-gray-800 text-sm mb-1"><?php echo e($item->name); ?></h4>
                    <p class="text-[#0f7ea0] font-bold">₱<?php echo e(number_format($item->price, 2)); ?></p>
                  </div>
                  <div class="w-10 h-10 bg-gradient-to-br from-[#0f7ea0] to-[#0c6b87] rounded-lg flex items-center justify-center">
                    <i class="fas fa-plus text-white text-sm"></i>
                  </div>
                </div>
              </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modern Payment Modal -->
<div id="paymentModal" class="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center hidden z-50">
  <div class="glass-card rounded-2xl p-8 w-96 shadow-2xl slide-in">
    <div class="text-center mb-6">
      <div class="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
        <i class="fas fa-money-bill-wave text-white text-xl"></i>
      </div>
      <h2 class="text-2xl font-bold text-gray-800">Process Payment</h2>
      <p class="text-gray-500">Enter the cash amount received</p>
    </div>

    <div class="space-y-4">
      <div>
        <label for="cashAmount" class="block text-sm font-semibold text-gray-700 mb-2">Cash Amount</label>
        <div class="relative">
          <span class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₱</span>
          <input type="number" id="cashAmount" 
                 class="w-full pl-8 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300 bg-white shadow-sm text-lg font-semibold" 
                 min="0" step="0.01" />
        </div>
      </div>

      <div class="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4 border-2 border-green-200">
        <label class="block text-sm font-semibold text-gray-700 mb-1">Change</label>
        <div id="changeAmount" class="text-3xl font-bold text-green-600">₱0.00</div>
      </div>
    </div>

    <div class="flex gap-3 mt-8">
      <button id="cancelPayment" class="flex-1 modern-btn ripple px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold shadow-lg hover:bg-gray-600">
        Cancel
      </button>
      <button id="confirmPayment" class="flex-1 modern-btn ripple px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-semibold shadow-lg hover:from-green-600 hover:to-green-700">
        Confirm Payment
      </button>
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("searchItem");
  const productButtons = document.querySelectorAll(".product-btn");
  const posItems = document.getElementById("posItems");
  const totalQtyEl = document.getElementById("totalQty");
  const grandTotalEl = document.getElementById("grandTotal");
  const paymentModal = document.getElementById("paymentModal");
  const cashInput = document.getElementById("cashAmount");
  const changeAmountDisplay = document.getElementById("changeAmount");
  const payNowBtn = document.getElementById("payNow");
  const cancelPaymentBtn = document.getElementById("cancelPayment");
  const confirmPaymentBtn = document.getElementById("confirmPayment");
  const printBtn = document.getElementById("printReceipt");

  function updateTotals() {
    let totalQty = 0;
    let grandTotal = 0;
    document.querySelectorAll(".pos-row").forEach((row, index) => {
      row.querySelector(".row-number").textContent = index + 1;
      const qty = parseInt(row.querySelector(".qty").value) || 0;
      const price = parseFloat(row.querySelector(".price").dataset.price) || 0;
      const total = qty * price;
      row.querySelector(".total").textContent = `₱${total.toFixed(2)}`;
      totalQty += qty;
      grandTotal += total;
    });
    totalQtyEl.textContent = totalQty;
    grandTotalEl.textContent = `₱${grandTotal.toFixed(2)}`;
  }

  function rebindButtons() {
    document.querySelectorAll(".btn-minus").forEach((btn) => {
      btn.onclick = function () {
        const input = this.nextElementSibling;
        if (parseInt(input.value) > 1) {
          input.value = parseInt(input.value) - 1;
          updateTotals();
        }
      };
    });

    document.querySelectorAll(".btn-plus").forEach((btn) => {
      btn.onclick = function () {
        const input = this.previousElementSibling;
        input.value = parseInt(input.value) + 1;
        updateTotals();
      };
    });

    document.querySelectorAll(".btn-remove").forEach((btn) => {
      btn.onclick = function () {
        const row = this.closest(".pos-row");
        row.style.animation = 'fadeOut 0.3s ease-out';
        setTimeout(() => {
          row.remove();
          updateTotals();
        }, 300);
      };
    });

    document.querySelectorAll(".qty").forEach((input) => {
      input.onchange = updateTotals;
    });
  }

  function openPOSWithBilling(billId) {
    window.location.href = `/pos?bill_id=${billId}`;
  }

  function createPOSRow(name, price, id, type, qty = 1) {
    // Check if already exists
    let exists = false;
    document.querySelectorAll(".pos-row").forEach((row) => {
      const itemName = row.querySelector(".item-name").textContent;
      if (itemName === name) {
        const qtyInput = row.querySelector(".qty");
        qtyInput.value = parseInt(qtyInput.value) + qty;
        updateTotals();
        exists = true;
      }
    });
    if (exists) return;

    const row = document.createElement("div");
    row.className = "grid grid-cols-[50px_1fr_120px_100px_120px_60px] items-center text-center py-4 border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 pos-row fade-in";
    row.setAttribute("data-id", id);
    row.setAttribute("data-type", type);
    row.innerHTML = `
      <div class="row-number text-gray-500 font-medium">#</div>
      <div class="text-left px-3 item-name">
        <div class="font-semibold text-gray-800">${name}</div>
        <div class="text-xs text-gray-500">${type}</div>
      </div>
      <div class="flex justify-center items-center gap-2">
        <button class="qty-control btn-minus w-8 h-8 rounded-lg bg-gray-200 hover:bg-red-500 hover:text-white flex items-center justify-center text-sm font-bold transition-all duration-200">
          <i class="fas fa-minus text-xs"></i>
        </button>
        <input type="number" value="${qty}" class="qty w-16 text-center border border-gray-200 rounded-lg h-8 font-semibold focus:ring-2 focus:ring-[#0f7ea0] focus:border-transparent" min="1" />
        <button class="qty-control btn-plus w-8 h-8 rounded-lg bg-gray-200 hover:bg-green-500 hover:text-white flex items-center justify-center text-sm font-bold transition-all duration-200">
          <i class="fas fa-plus text-xs"></i>
        </button>
      </div>
      <div class="price font-semibold text-gray-700" data-price="${price}">₱${parseFloat(price).toFixed(2)}</div>
      <div class="font-bold text-[#0f7ea0] total">₱${(price * qty).toFixed(2)}</div>
      <div class="flex justify-center">
        <button class="btn-remove w-8 h-8 rounded-lg bg-red-100 hover:bg-red-500 hover:text-white flex items-center justify-center transition-all duration-200 group">
          <i class="fas fa-trash text-xs text-red-500 group-hover:text-white"></i>
        </button>
      </div>
    `;
    posItems.appendChild(row);
    rebindButtons();
    updateTotals();
  }

  productButtons.forEach((btn) => {
    btn.addEventListener("click", function () {
      const id = this.dataset.id;
      const name = this.dataset.name;
      const price = parseFloat(this.dataset.price);
      const type = this.dataset.type;
      
      // Add ripple effect
      this.style.transform = 'scale(0.95)';
      setTimeout(() => {
        this.style.transform = '';
      }, 150);
      
      createPOSRow(name, price, id, type);
    });
  });

  searchInput.addEventListener("input", function () {
    const keyword = this.value.toLowerCase();
    productButtons.forEach((btn) => {
      const name = btn.dataset.name.toLowerCase();
      const container = btn.parentElement;
      if (name.includes(keyword)) {
        btn.style.display = "block";
        btn.classList.add("fade-in");
      } else {
        btn.style.display = "none";
      }
    });
  });

  payNowBtn.addEventListener("click", () => {
    const grandTotal = parseFloat(grandTotalEl.textContent.replace("₱", ""));
    if (grandTotal === 0) {
      alert("Please add items to cart first.");
      return;
    }
    cashInput.value = "";
    changeAmountDisplay.textContent = "₱0.00";
    paymentModal.classList.remove("hidden");
    setTimeout(() => cashInput.focus(), 300);
  });

  cancelPaymentBtn.addEventListener("click", () => {
    paymentModal.classList.add("hidden");
  });

  cashInput.addEventListener("input", () => {
    const grandTotal = parseFloat(grandTotalEl.textContent.replace("₱", ""));
    const cash = parseFloat(cashInput.value) || 0;
    const change = Math.max(0, cash - grandTotal);
    changeAmountDisplay.textContent = `₱${change.toFixed(2)}`;
    
    // Visual feedback for sufficient payment
    if (cash >= grandTotal && grandTotal > 0) {
      changeAmountDisplay.classList.add("text-green-600");
      changeAmountDisplay.classList.remove("text-red-500");
    } else {
      changeAmountDisplay.classList.add("text-red-500");
      changeAmountDisplay.classList.remove("text-green-600");
    }
  });

  confirmPaymentBtn.addEventListener("click", () => {
    const grandTotal = parseFloat(grandTotalEl.textContent.replace("₱", ""));
    const cash = parseFloat(cashInput.value) || 0;
    
    if (cash < grandTotal) {
      alert("Insufficient cash amount.");
      cashInput.focus();
      return;
    }

    const items = [];
    document.querySelectorAll(".pos-row").forEach(row => {
      items.push({
        product_id: row.getAttribute("data-id"),
        type: row.getAttribute("data-type"),
        name: row.querySelector(".item-name").textContent,
        quantity: parseInt(row.querySelector(".qty").value),
        price: parseFloat(row.querySelector(".price").dataset.price)
      });
    });

    // Show loading state
    confirmPaymentBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processing...';
    confirmPaymentBtn.disabled = true;

    fetch("/sales", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
      },
      body: JSON.stringify({ items, cash, total: grandTotal })
    })
    .then(res => res.json())
    .then(data => {
      paymentModal.classList.add("hidden");
      
      // Success notification
      const successDiv = document.createElement("div");
      successDiv.className = "fixed top-4 right-4 bg-green-500 text-white px-6 py-4 rounded-xl shadow-lg z-50 fade-in";
      successDiv.innerHTML = '<i class="fas fa-check-circle mr-2"></i>Payment successful!';
      document.body.appendChild(successDiv);
      
      setTimeout(() => {
        successDiv.remove();
        location.reload();
      }, 2000);
    })
    .catch(err => {
      alert("Payment failed. Please try again.");
      console.error(err);
      confirmPaymentBtn.innerHTML = 'Confirm Payment';
      confirmPaymentBtn.disabled = false;
    });
  });

  // Add CSS for fade out animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fadeOut {
      to { opacity: 0; transform: translateX(100%); }
    }
  `;
  document.head.appendChild(style);
});

// Pre-populate items from server
<?php $__currentLoopData = $posItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  createPOSRow("<?php echo e($item['name']); ?>", <?php echo e($item['price']); ?>, <?php echo e($item['id']); ?>, "<?php echo e($item['type']); ?>", <?php echo e($item['qty']); ?>);
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\OneDrive\Desktop\Multi-branchVCMS\MBVCMS\resources\views/pos.blade.php ENDPATH**/ ?>