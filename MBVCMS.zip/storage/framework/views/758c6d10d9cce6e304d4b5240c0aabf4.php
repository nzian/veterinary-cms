<!DOCTYPE html>
<html>
<head>
    <title>Receipt</title>
    <style>
        /* Add your styles here */
    </style>
</head>
<body>
    <h2>Receipt #<?php echo e($transaction->id); ?></h2>
    <p>Customer: <?php echo e($transaction->customer_name); ?></p>
    <p>Date: <?php echo e(\Carbon\Carbon::parse($transaction->created_at)->format('F d, Y')); ?></p>

    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaction->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td><?php echo e(number_format($item->price, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p>Total: <?php echo e(number_format($transaction->total, 2)); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Multi-branchVCMS\MBVCMS\resources\views/receipt-print.blade.php ENDPATH**/ ?>