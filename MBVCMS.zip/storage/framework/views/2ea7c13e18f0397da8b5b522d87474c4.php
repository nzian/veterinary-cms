

<?php $__env->startSection('content'); ?>
<div class="min-h-screen">
    <div class="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow">
        
        
        <div class="flex border-b border-gray-200 mb-6">
            <button onclick="switchTab('branches')" id="branchesTab" 
                class="tab-btn px-6 py-3 text-sm font-medium border-b-2 border-[#0f7ea0] text-[#0f7ea0] bg-blue-50">
                Branch Management
            </button>
            <button onclick="switchTab('users')" id="usersTab" 
                class="tab-btn px-6 py-3 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                User Management
            </button>
        </div>

        
        <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-2 rounded mb-4 text-sm">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        
        <div id="branchesContent" class="tab-content">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-[#0f7ea0] font-bold text-xl">Branches</h2>
                <button onclick="openAddModal()" class="bg-[#0f7ea0] text-white text-sm px-4 py-2 rounded hover:bg-[#0c6a86]">
                    + Add Branch
                </button>
            </div>

            <div class="flex justify-between items-center mt-4 text-sm font-semibold text-black">
                <form method="GET" action="<?php echo e(request()->url()); ?>" class="flex items-center space-x-2">
                    <label for="perPageBranches" class="text-sm text-black">Show</label>
                    <select name="perPage" id="perPageBranches" onchange="this.form.submit()"
                        class="border border-gray-400 rounded px-2 py-1 text-sm">
                        <?php $__currentLoopData = [10, 20, 50, 100, 'all']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($limit); ?>" <?php echo e(request('perPage') == $limit ? 'selected' : ''); ?>>
                            <?php echo e($limit === 'all' ? 'All' : $limit); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span>entries</span>
                </form>
            </div>
            <br>

            <div class="overflow-x-auto">
                <table class="w-full table-auto text-sm border text-center">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="border px-2 py-1">#</th>
                            <th class="border px-2 py-1">Branch Name</th>
                            <th class="border px-2 py-1">Address</th>
                            <th class="border px-2 py-1">Contact</th>
                            <th class="border px-2 py-1">Action</th>
                        </tr>
                    </thead>
                    <tbody id="branchTableBody">
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-2 py-1"><?php echo e($index + 1); ?></td>
                            <td class="border px-2 py-1"><?php echo e($branch->branch_name); ?></td>
                            <td class="border px-2 py-1"><?php echo e($branch->branch_address); ?></td>
                            <td class="border px-2 py-1"><?php echo e($branch->branch_contactNum); ?></td>
                            <td class="border px-2 py-1">
                                <div class="flex justify-center items-center gap-1">
                                    <button
                                        class="editBranchBtn bg-[#0f7ea0] text-white px-2 py-1 rounded hover:bg-[#0c6a86] flex items-center gap-1 text-xs"
                                        data-id="<?php echo e($branch->branch_id); ?>" data-name="<?php echo e($branch->branch_name); ?>"
                                        data-address="<?php echo e($branch->branch_address); ?>" data-contact="<?php echo e($branch->branch_contactNum); ?>">
                                        <i class="fas fa-pen"></i> 
                                    </button>
                                    <button onclick='openViewModal(<?php echo json_encode($branch, 15, 512) ?>)'
                                        class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 flex items-center gap-1 text-xs">
                                        <i class="fas fa-eye"></i> 
                                    </button>
                                    <form action="<?php echo e(route('branches-destroy', $branch->branch_id)); ?>" method="POST"
                                        onsubmit="return confirm('Delete this branch?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="bg-[#f44336] text-white px-2 py-1 rounded hover:bg-red-600 flex items-center gap-1 text-xs">
                                            <i class="fas fa-trash"></i> 
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div id="usersContent" class="tab-content hidden">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-[#0f7ea0] font-bold text-lg">User Management</h2>
                <button onclick="openAddUserModal()"
                    class="bg-[#0f7ea0] text-white text-sm px-4 py-2 rounded hover:bg-[#0c6a86]">
                    + Add User
                </button>
            </div>

            <div class="flex justify-between items-center mt-4 text-sm font-semibold text-black">
                <form method="GET" action="<?php echo e(request()->url()); ?>" class="flex items-center space-x-2">
                    <label for="perPageUsers" class="text-sm text-black">Show</label>
                    <select name="perPage" id="perPageUsers" onchange="this.form.submit()"
                        class="border border-gray-400 rounded px-2 py-1 text-sm">
                        <?php $__currentLoopData = [10, 20, 50, 100, 'all']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($limit); ?>" <?php echo e(request('perPage') == $limit ? 'selected' : ''); ?>>
                            <?php echo e($limit === 'all' ? 'All' : $limit); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span>entries</span>
                </form>
            </div>
            <br>

            <div class="overflow-x-auto">
                <table class="w-full table-auto text-sm border text-center">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="border px-2 py-2">#</th>
                            <th class="border px-2 py-2">Name</th>
                            <th class="border px-2 py-2">Email</th>
                            <th class="border px-2 py-2">Role</th>
                            <th class="border px-2 py-2">Branch</th>
                            <th class="border px-2 py-2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="border px-2 py-2"><?php echo e($index + 1); ?></td>
                            <td class="border px-2 py-2"><?php echo e($user->user_name); ?></td>
                            <td class="border px-2 py-2"><?php echo e($user->user_email); ?></td>
                            <td class="border px-2 py-2 capitalize"><?php echo e($user->user_role); ?></td>
                            <td class="border px-2 py-2"><?php echo e($user->branch->branch_name ?? 'All Branches'); ?></td>
                            <td class="border px-2 py-1">
                                <div class="flex justify-center items-center gap-1">
                                    <button
                                        class="editUserBtn bg-[#0f7ea0] text-white px-2 py-1 rounded hover:bg-[#0c6a86] flex items-center gap-1 text-xs"
                                        data-id="<?php echo e($user->user_id); ?>" data-name="<?php echo e($user->user_name); ?>"
                                        data-email="<?php echo e($user->user_email); ?>" data-role="<?php echo e($user->user_role); ?>"
                                        data-branch="<?php echo e($user->branch_id); ?>">
                                        <i class="fas fa-pen"></i> 
                                    </button>
                                    <form action="<?php echo e(route('userManagement.destroy', $user->user_id)); ?>" method="POST"
                                        onsubmit="return confirm('Delete this user?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="bg-[#f44336] text-white px-2 py-1 rounded hover:bg-red-600 flex items-center gap-1 text-xs">
                                            <i class="fas fa-trash"></i> 
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-gray-500 py-4">No users found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <!-- Add Branch Modal -->
    <div id="branchModal" class="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-lg p-6 rounded shadow-lg relative">
            <form action="<?php echo e(route('branches.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h3 class="text-lg font-semibold text-[#0f7ea0] mb-4">Add New Branch</h3>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Name</label>
                    <input type="text" name="name" required class="w-full border rounded p-2" />
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Address</label>
                    <input type="text" name="address" required class="w-full border rounded p-2" />
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Contact</label>
                    <input type="text" name="contact" required class="w-full border rounded p-2" />
                </div>

                <div class="flex justify-end space-x-2 mt-4">
                    <button type="button" onclick="closeBranchModal()"
                        class="px-4 py-1 bg-gray-300 rounded text-sm hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="px-4 py-1 bg-[#0f7ea0] text-white rounded text-sm hover:bg-[#0d6b85]">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Branch Modal -->
    <div id="editBranchModal" class="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center hidden z-50">
        <div class="bg-white p-6 rounded shadow w-full max-w-md relative">
            <form id="editBranchForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <h3 class="text-lg font-semibold text-[#0f7ea0] mb-4">Edit Branch</h3>
                
                <input type="hidden" name="branch_id" id="edit_branch_id">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Name:</label>
                    <input type="text" name="name" id="edit_name" class="w-full border p-2 rounded">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Address:</label>
                    <input type="text" name="address" id="edit_address" class="w-full border p-2 rounded">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Contact:</label>
                    <input type="text" name="contact" id="edit_contact" class="w-full border p-2 rounded">
                </div>
                <div class="flex justify-end space-x-2 mt-4">
                    <button type="button" class="px-4 py-1 bg-gray-300 rounded text-sm hover:bg-gray-400"
                        onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="px-4 py-1 bg-[#0f7ea0] text-white rounded text-sm hover:bg-[#0d6b85]">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Branch Modal -->
    <div id="viewBranchModal" class="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center hidden z-50">
        <div class="bg-white p-6 rounded shadow w-full max-w-md relative">
            <h2 class="text-lg font-semibold text-[#0f7ea0] mb-4">Branch Details</h2>
            <div class="space-y-2 text-sm">
                <p><strong>Name:</strong> <span id="view_branch_name"></span></p>
                <p><strong>Address:</strong> <span id="view_branch_address"></span></p>
                <p><strong>Contact:</strong> <span id="view_branch_contact"></span></p>
            </div>
            <div class="flex justify-end mt-4">
                <button onclick="closeViewModal()" class="px-4 py-1 bg-gray-300 rounded text-sm hover:bg-gray-400">Close</button>
            </div>
        </div>
    </div>

    
    <!-- Add User Modal -->
    <div id="userModal" class="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-lg p-6 rounded shadow-lg relative">
            <form action="<?php echo e(route('userManagement.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h3 class="text-lg font-semibold text-[#0f7ea0] mb-4">Add New User</h3>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Full Name</label>
                    <input type="text" name="user_name" required class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Email</label>
                    <input type="email" name="user_email" required class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Password</label>
                    <input type="password" name="user_password" required class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Confirm Password</label>
                    <input type="password" name="user_password_confirmation" required
                        class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Role</label>
                    <select name="user_role" required class="w-full border rounded px-2 py-1 text-sm">
                        <option value="">Select Role</option>
                        <option value="veterinarian">Veterinarian</option>
                        <option value="receptionist">Receptionist</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Branch</label>
                    <select name="branch_id" required class="w-full border rounded px-2 py-1 text-sm">
                        <option value="">Select Branch</option>
                        <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($branch->branch_id); ?>"><?php echo e($branch->branch_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option disabled>No branches found</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="flex justify-end space-x-2 mt-4">
                    <button type="button" class="px-4 py-1 bg-gray-300 rounded text-sm hover:bg-gray-400"
                        onclick="closeUserModal()">Cancel</button>
                    <button type="submit"
                        class="px-4 py-1 bg-[#0f7ea0] text-white rounded text-sm hover:bg-[#0d6b85]">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div id="editUserModal" class="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-lg p-6 rounded shadow-lg relative">
            <form id="editUserForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <h3 class="text-lg font-semibold text-[#0f7ea0] mb-4">Edit User</h3>

                <input type="hidden" name="user_id" id="edit_user_id">

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Full Name</label>
                    <input type="text" name="user_name" id="edit_user_name" required
                        class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Email</label>
                    <input type="email" name="user_email" id="edit_user_email" required
                        class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Password (leave blank to keep current)</label>
                    <input type="password" name="user_password" id="edit_user_password"
                        class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Confirm Password</label>
                    <input type="password" name="user_password_confirmation" id="edit_user_password_confirmation"
                        class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Role</label>
                    <select name="user_role" id="edit_user_role" required class="w-full border rounded px-2 py-1 text-sm">
                        <option value="">Select Role</option>
                        <option value="veterinarian">Veterinarian</option>
                        <option value="receptionist">Receptionist</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Branch</label>
                    <select name="branch_id" id="edit_user_branch" required class="w-full border rounded px-2 py-1 text-sm">
                        <option value="">Select Branch</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->branch_id); ?>"><?php echo e($branch->branch_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="flex justify-end space-x-2 mt-4">
                    <button type="button" class="px-4 py-1 bg-gray-300 rounded text-sm hover:bg-gray-400"
                        onclick="closeEditUserModal()">Cancel</button>
                    <button type="submit" class="px-4 py-1 bg-[#0f7ea0] text-white rounded text-sm hover:bg-[#0d6b85]">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Tab switching functionality
    function switchTab(tabName) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        
        // Remove active styling from all tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('border-[#0f7ea0]', 'text-[#0f7ea0]', 'bg-blue-50');
            btn.classList.add('border-transparent', 'text-gray-500');
        });
        
        // Show selected tab content
        document.getElementById(tabName + 'Content').classList.remove('hidden');
        
        // Add active styling to selected tab
        const activeTab = document.getElementById(tabName + 'Tab');
        activeTab.classList.remove('border-transparent', 'text-gray-500');
        activeTab.classList.add('border-[#0f7ea0]', 'text-[#0f7ea0]', 'bg-blue-50');
        
        // Store active tab in localStorage
        localStorage.setItem('activeTab', tabName);
    }

    // Branch functionality
    function openViewModal(branch) {
        document.getElementById('view_branch_name').innerText = branch.branch_name;
        document.getElementById('view_branch_address').innerText = branch.branch_address;
        document.getElementById('view_branch_contact').innerText = branch.branch_contactNum;
        document.getElementById('viewBranchModal').classList.remove('hidden');
    }

    function closeViewModal() {
        document.getElementById('viewBranchModal').classList.add('hidden');
    }

    function openAddModal() {
        document.getElementById('branchModal').classList.remove('hidden');
    }

    function closeBranchModal() {
        document.getElementById('branchModal').classList.add('hidden');
    }

    function closeEditModal() {
        document.getElementById('editBranchModal').classList.add('hidden');
    }

    // User functionality
    function openAddUserModal() {
        document.getElementById('userModal').classList.remove('hidden');
    }

    function closeUserModal() {
        document.getElementById('userModal').classList.add('hidden');
    }

    function closeEditUserModal() {
        document.getElementById('editUserModal').classList.add('hidden');
    }

    // Initialize page
    document.addEventListener('DOMContentLoaded', function () {
        // Restore active tab from localStorage or default to branches
        const activeTab = localStorage.getItem('activeTab') || 'branches';
        switchTab(activeTab);

        // Branch edit functionality
        document.querySelectorAll('.editBranchBtn').forEach(btn => {
            btn.addEventListener('click', function () {
                const id = this.dataset.id;
                const name = this.dataset.name;
                const address = this.dataset.address;
                const contact = this.dataset.contact;

                // Fill modal form
                document.getElementById('edit_branch_id').value = id;
                document.getElementById('edit_name').value = name;
                document.getElementById('edit_address').value = address;
                document.getElementById('edit_contact').value = contact;

                // Set form action
                document.getElementById('editBranchForm').action = `/branches/${id}`;

                // Show modal
                document.getElementById('editBranchModal').classList.remove('hidden');
            });
        });

        // User edit functionality
        document.querySelectorAll('.editUserBtn').forEach(button => {
            button.addEventListener('click', function () {
                const userId = this.dataset.id;
                const user_name = this.dataset.name;
                const user_email = this.dataset.email;
                const user_role = this.dataset.role;
                const branch = this.dataset.branch;

                // Fill form
                document.getElementById('edit_user_id').value = userId;
                document.getElementById('edit_user_name').value = user_name;
                document.getElementById('edit_user_email').value = user_email;
                document.getElementById('edit_user_role').value = user_role;
                document.getElementById('edit_user_branch').value = branch;

                // Reset password fields
                document.getElementById('edit_user_password').value = "";
                document.getElementById('edit_user_password_confirmation').value = "";

                // Set dynamic action
                document.getElementById('editUserForm').action = `<?php echo e(url('user-management')); ?>/${userId}`;

                // Show modal
                document.getElementById('editUserModal').classList.remove('hidden');
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Multi-branchVCMS\MBVCMS\resources\views/management.blade.php ENDPATH**/ ?>