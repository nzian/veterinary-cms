

<?php $__env->startSection('content'); ?>
<div class="min-h-screen">
    <div class="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-[#0f7ea0] font-bold text-xl">Products</h2>
            <button onclick="openAddModal()"
                class="bg-[#0f7ea0] text-white text-sm px-4 py-2 rounded hover:bg-[#0c6a86]">
                + Add Product
            </button>
        </div>

        <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 text-sm px-4 py-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="w-full table-auto text-sm border text-center">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="border px-2 py-2">Name</th>
                        <th class="border px-2 py-2">Category</th>
                        <th class="border px-2 py-2">Description</th>
                        <th class="border px-2 py-2">Price</th>
                        <th class="border px-2 py-2">Stocks</th>
                        <th class="border px-2 py-2">Reorder Level</th>
                       
                        <th class="border px-2 py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-2 py-1"><?php echo e($product->prod_name); ?></td>
                        <td class="border px-2 py-1"><?php echo e($product->prod_category); ?></td>
                        <td class="border px-2 py-1"><?php echo e($product->prod_description); ?></td>
                        <td class="border px-2 py-1">₱<?php echo e(number_format($product->prod_price, 2)); ?></td>
                        <td class="border px-2 py-1"><?php echo e($product->prod_stocks); ?></td>
                         <td class="border px-2 py-1"><?php echo e($product->prod_reorderlevel); ?></td>
                        <td class="border px-2 py-1">
                            <div class="flex gap-2">
                                <button onclick="openEditModal(<?php echo e($product); ?>)"
                                   class="bg-[#0f7ea0] text-white px-2 py-1 rounded hover:bg-[#0c6a86] flex items-center gap-1 text-xs">
                                    <i class="fas fa-pen"></i> Edit
                                </button>
                                <form action="<?php echo e(route('products.destroy', $product->prod_id)); ?>" method="POST"
                                    onsubmit="return confirm('Delete this product?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button
                                        class="bg-red-500 text-white px-2 py-1 rounded text-xs hover:bg-red-600">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Product Modal -->
<div id="addModal" class="fixed inset-0 hidden bg-black bg-opacity-30 flex justify-center items-center z-50">
    <div class="bg-white p-6 rounded-lg w-full max-w-lg shadow">
        <h3 class="text-lg font-bold mb-4 text-[#0f7ea0]"></h3>
        <form action="<?php echo e(route('products.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-3">
    <div>
        <label for="prod_name" class="block text-sm font-medium text-gray-700 mb-1">Product Name</label>
        <input type="text" id="prod_name" name="prod_name" class="border p-2 rounded w-full" required>
    </div>

    <div>
        <label for="prod_category" class="block text-sm font-medium text-gray-700 mb-1">Category</label>
        <input type="text" id="prod_category" name="prod_category" class="border p-2 rounded w-full" required>
    </div>

    <div>
        <label for="prod_description" class="block text-sm font-medium text-gray-700 mb-1">Description</label>
        <input type="text" id="prod_description" name="prod_description" class="border p-2 rounded w-full" required>
    </div>

    <div>
        <label for="prod_price" class="block text-sm font-medium text-gray-700 mb-1">Price</label>
        <input type="number" id="prod_price" name="prod_price" class="border p-2 rounded w-full" required>
    </div>

    <div>
        <label for="prod_stocks" class="block text-sm font-medium text-gray-700 mb-1">Stocks</label>
        <input type="number" id="prod_stocks" name="prod_stocks" class="border p-2 rounded w-full" required>
    </div>

    <div>
        <label for="prod_reorderlevel" class="block text-sm font-medium text-gray-700 mb-1">Reorder Level</label>
        <input type="number" id="prod_reorderlevel" name="prod_reorderlevel" class="border p-2 rounded w-full" required>
    </div>
</div>

            <div class="mt-4 flex justify-end gap-2">
                <button type="button" onclick="closeAddModal()"
                    class="bg-gray-300 text-gray-700 px-3 py-1 rounded">Cancel</button>
                <button type="submit"
                    class="bg-[#0f7ea0] text-white px-4 py-1 rounded hover:bg-[#0c6a86]">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Product Modal -->
<div id="editModal" class="fixed inset-0 hidden bg-black bg-opacity-30 flex justify-center items-center z-50">
    <div class="bg-white p-6 rounded-lg w-full max-w-lg shadow">
        <h3 class="text-lg font-bold mb-4 text-[#0f7ea0]">Edit Product</h3>
        <form id="editForm" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="grid grid-cols-2 gap-3">
                <input type="text" id="edit_name" name="prod_name" class="border p-2 rounded" required>
                <input type="text" id="edit_category" name="prod_category" class="border p-2 rounded" required>
                <input type="text" id="edit_description" name="prod_description" class="border p-2 rounded" required>
                <input type="number" id="edit_price" name="prod_price" class="border p-2 rounded" required>
                <input type="number" id="edit_stocks" name="prod_stocks" class="border p-2 rounded" required>
                <input type="number" id="edit_reorder" name="prod_reorderlevel" class="border p-2 rounded" required>
            </div>
            <div class="mt-4 flex justify-end gap-2">
                <button type="button" onclick="closeEditModal()"
                    class="bg-gray-300 text-gray-700 px-3 py-1 rounded">Cancel</button>
                <button type="submit"
                    class="bg-[#0f7ea0] text-white px-4 py-1 rounded hover:bg-[#0c6a86]">Update</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('addModal').classList.remove('hidden');
    }

    function closeAddModal() {
        document.getElementById('addModal').classList.add('hidden');
    }

    function openEditModal(product) {
        document.getElementById('editForm').action = `/products/${product.prod_id}`;
        document.getElementById('edit_name').value = product.prod_name;
        document.getElementById('edit_category').value = product.prod_category;
        document.getElementById('edit_description').value = product.prod_description;
        document.getElementById('edit_price').value = product.prod_price;
        document.getElementById('edit_stocks').value = product.prod_stocks;
        document.getElementById('edit_reorder').value = product.prod_reorderlevel;
        document.getElementById('editModal').classList.remove('hidden');
    }

    function closeEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\OneDrive\Desktop\Multi-branchVCMS\MBVCMS\resources\views/product.blade.php ENDPATH**/ ?>