

<?php $__env->startSection('content'); ?>
<div class="min-h-screen">
    <div class="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow">
        <style>
            .tab-active {
                background-color: #0c6a86 !important;
                color: white !important;
            }
        </style>

        <div class="p-6">
            <ul class="flex border-b" id="tabs">
                <?php for($i = 1; $i <= 10; $i++): ?>
                    <li class="-mb-px mr-1">
                        <a id="tab-link-<?php echo e($i); ?>"
                           class="bg-white inline-block border-l border-t border-r rounded-t py-2 px-4 text-black-700 font-medium cursor-pointer"
                           onclick="showTab(<?php echo e($i); ?>)">Report <?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>
            </ul>

            <?php
                $reportDescriptions = [
                    1 => 'Pet Owner and Pet together with Appointments handled by Users at the branch',
                    2 => 'Pet Owner together with their Pet',
                    3 => 'Pet Owner and Pet with Appointment including Billing and Payment',
                    4 => 'Product purchased by Pet Owner via order handled by User',
                    5 => 'Created Referral from Appointment together with Pet owner and Pet to other Branches',
                    6 => 'Services provided during Appointment for Pet with its Owner handled by User',
                    7 => 'User assigned per branches',
                    8 => 'Billing information with related Orders to the Pet Owner',
                    9 => 'Sold Product to Pet owner handled by every User',
                    10 => 'Collected Payment from Pet owner with Appointment and Billing details of Pet handled by User',
                ];
            ?>


            <?php for($i = 1; $i <= 10; $i++): ?>
                <?php $report = ${"report$i"}; ?>
                <div id="tab<?php echo e($i); ?>" class="tab-content <?php echo e($i === 1 ? '' : 'hidden'); ?> mt-4 overflow-x-auto">
                    <div class="mb-2 text-gray-800 font-semibold">
                        <?php echo e($reportDescriptions[$i]); ?>

                    </div>

                    <br>

                    <?php if(count($report) > 0): ?>
                        <table class="min-w-full border text-sm text-left text-black">
                            <thead>
                                <tr>
                                    <?php $__currentLoopData = $report[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="border px-2 py-1"><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="border px-2 py-1"><?php echo e($cell); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="text-gray-500 italic">No data available for Report <?php echo e($i); ?>.</div>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</div>

<script>
    function showTab(tabNumber) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach((el) => el.classList.add('hidden'));

        // Show the selected tab content
        document.getElementById('tab' + tabNumber).classList.remove('hidden');

        // Remove active class from all tab links
        document.querySelectorAll('#tabs a').forEach((link) => {
            link.classList.remove('tab-active');
        });

        // Add active class to clicked tab link
        document.getElementById('tab-link-' + tabNumber).classList.add('tab-active');
    }

    // Set default active tab on page load
    window.addEventListener('DOMContentLoaded', () => {
        document.getElementById('tab-link-1').classList.add('tab-active');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\OneDrive\Desktop\Multi-branchVCMS\MBVCMS\resources\views/report.blade.php ENDPATH**/ ?>