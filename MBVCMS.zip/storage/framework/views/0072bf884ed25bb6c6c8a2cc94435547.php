

<?php $__env->startSection('content'); ?>
<div class="min-h-screen">
    <div class="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow">
        
        
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-2 rounded mb-4 text-sm">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="bg-red-500 text-white p-2 rounded mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <div class="border-b border-gray-200 mb-6">
            <nav class="-mb-px flex space-x-8">
                <button onclick="switchTab('branches')" id="branches-tab" 
                    class="tab-button py-2 px-1 border-b-2 font-medium text-sm <?php echo e(request('tab', 'branches') == 'branches' ? 'active' : ''); ?>">
                    Branches
                </button>
                <button onclick="switchTab('users')" id="users-tab" 
                    class="tab-button py-2 px-1 border-b-2 font-medium text-sm <?php echo e(request('tab') == 'users' ? 'active' : ''); ?>">
                    User Management
                </button>
            </nav>
        </div>

        
        <div id="branches-content" class="tab-content <?php echo e(request('tab', 'branches') != 'branches' ? 'hidden' : ''); ?>">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-[#0f7ea0] font-bold text-xl">Branches</h2>
                <button onclick="openAddBranchModal()" class="bg-[#0f7ea0] text-white text-sm px-4 py-2 rounded hover:bg-[#0c6a86]">
                    + Add Branch
                </button>
            </div>

            <div class="flex justify-between items-center mt-4 text-sm font-semibold text-black">
                <form method="GET" action="<?php echo e(request()->url()); ?>" class="flex items-center space-x-2">
                    <input type="hidden" name="tab" value="branches">
                    <label for="branchesPerPage" class="text-sm text-black">Show</label>
                    <select name="branchesPerPage" id="branchesPerPage" onchange="this.form.submit()"
                        class="border border-gray-400 rounded px-2 py-1 text-sm">
                        <?php $__currentLoopData = [10, 20, 50, 100, 'all']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($limit); ?>" <?php echo e(request('branchesPerPage') == $limit ? 'selected' : ''); ?>>
                                <?php echo e($limit === 'all' ? 'All' : $limit); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span>entries</span>
                </form>
            </div>

            <div class="overflow-x-auto mt-4">
                <table class="w-full table-auto text-sm border text-center">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="border px-2 py-2">#</th>
                            <th class="border px-2 py-2">Branch Name</th>
                            <th class="border px-2 py-2">Address</th>
                            <th class="border px-2 py-2">Contact</th>
                            <th class="border px-2 py-2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="border px-2 py-2">
                                    <?php if(method_exists($branches, 'firstItem')): ?>
                                        <?php echo e($branches->firstItem() + $index); ?>

                                    <?php else: ?>
                                        <?php echo e($index + 1); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="border px-2 py-2"><?php echo e($branch->branch_name); ?></td>
                                <td class="border px-2 py-2"><?php echo e($branch->branch_address); ?></td>
                                <td class="border px-2 py-2"><?php echo e($branch->branch_contactNum); ?></td>
                                <td class="border px-2 py-1">
                                    <div class="flex justify-center items-center gap-1">
                                        <button class="editBranchBtn bg-[#0f7ea0] text-white px-2 py-1 rounded hover:bg-[#0c6a86] flex items-center gap-1 text-xs"
                                            data-id="<?php echo e($branch->branch_id); ?>"
                                            data-name="<?php echo e($branch->branch_name); ?>"
                                            data-address="<?php echo e($branch->branch_address); ?>"
                                            data-contact="<?php echo e($branch->branch_contactNum); ?>">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                        
                                        <button onclick="viewBranchDetails(this)" class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 flex items-center gap-1 text-xs"
                                            data-name="<?php echo e($branch->branch_name); ?>"
                                            data-address="<?php echo e($branch->branch_address); ?>"
                                            data-contact="<?php echo e($branch->branch_contactNum); ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <form action="<?php echo e(route('branches-destroy', $branch->branch_id)); ?>" method="POST"
                                            onsubmit="return confirm('Are you sure you want to delete this branch?');" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="tab" value="branches">
                                            <button type="submit" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 flex items-center gap-1 text-xs">
                                                <i class="fas fa-trash"></i> 
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-gray-500 py-4">No branches found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if(method_exists($branches, 'hasPages') && $branches->hasPages()): ?>
            <div class="flex justify-between items-center mt-4 text-sm font-semibold text-black">
                <div>
                    <?php if(method_exists($branches, 'firstItem')): ?>
                        Showing <?php echo e($branches->firstItem()); ?> to <?php echo e($branches->lastItem()); ?> of <?php echo e($branches->total()); ?> entries
                    <?php else: ?>
                        Showing <?php echo e($branches->count()); ?> entries
                    <?php endif; ?>
                </div>
                <div class="inline-flex border border-gray-400 rounded overflow-hidden">
                    <?php if($branches->onFirstPage()): ?>
                        <button disabled class="px-3 py-1 text-gray-400 cursor-not-allowed border-r">Previous</button>
                    <?php else: ?>
                        <a href="<?php echo e($branches->appends(array_merge(request()->query(), ['tab' => 'branches']))->previousPageUrl()); ?>" class="px-3 py-1 text-black hover:bg-gray-200 border-r">Previous</a>
                    <?php endif; ?>

                    <?php for($i = 1; $i <= $branches->lastPage(); $i++): ?>
                        <?php if($i == $branches->currentPage()): ?>
                            <button class="px-3 py-1 bg-[#0f7ea0] text-white border-r"><?php echo e($i); ?></button>
                        <?php else: ?>
                            <a href="<?php echo e($branches->appends(array_merge(request()->query(), ['tab' => 'branches']))->url($i)); ?>" class="px-3 py-1 hover:bg-gray-200 border-r"><?php echo e($i); ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($branches->hasMorePages()): ?>
                        <a href="<?php echo e($branches->appends(array_merge(request()->query(), ['tab' => 'branches']))->nextPageUrl()); ?>" class="px-3 py-1 text-black hover:bg-gray-200">Next</a>
                    <?php else: ?>
                        <button disabled class="px-3 py-1 text-gray-400 cursor-not-allowed">Next</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        
        <div id="users-content" class="tab-content <?php echo e(request('tab') != 'users' ? 'hidden' : ''); ?>">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-[#0f7ea0] font-bold text-xl">User Management</h2>
                <button onclick="openAddUserModal()" class="bg-[#0f7ea0] text-white text-sm px-4 py-2 rounded hover:bg-[#0c6a86]">
                    + Add User
                </button>
            </div>

            <div class="flex justify-between items-center mt-4 text-sm font-semibold text-black">
                <form method="GET" action="<?php echo e(request()->url()); ?>" class="flex items-center space-x-2">
                    <input type="hidden" name="tab" value="users">
                    <label for="usersPerPage" class="text-sm text-black">Show</label>
                    <select name="usersPerPage" id="usersPerPage" onchange="this.form.submit()"
                        class="border border-gray-400 rounded px-2 py-1 text-sm">
                        <?php $__currentLoopData = [10, 20, 50, 100, 'all']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($limit); ?>" <?php echo e(request('usersPerPage') == $limit ? 'selected' : ''); ?>>
                                <?php echo e($limit === 'all' ? 'All' : $limit); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span>entries</span>
                </form>
            </div>

            <div class="overflow-x-auto mt-4">
                <table class="w-full table-auto text-sm border text-center">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="border px-2 py-2">#</th>
                            <th class="border px-2 py-2">Name</th>
                            <th class="border px-2 py-2">Email</th>
                            <th class="border px-2 py-2">Role</th>
                            <th class="border px-2 py-2">Branch</th>
                            <th class="border px-2 py-2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="border px-2 py-2">
                                    <?php if(method_exists($users, 'firstItem')): ?>
                                        <?php echo e($users->firstItem() + $index); ?>

                                    <?php else: ?>
                                        <?php echo e($index + 1); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="border px-2 py-2"><?php echo e($user->user_name); ?></td>
                                <td class="border px-2 py-2"><?php echo e($user->user_email); ?></td>
                                <td class="border px-2 py-2 capitalize"><?php echo e($user->user_role); ?></td>
                                <td class="border px-2 py-2"><?php echo e($user->branch->branch_name ?? 'All Branches'); ?></td>
                                <td class="border px-2 py-1">
                                    <div class="flex justify-center items-center gap-1">
                                        <button class="editUserBtn bg-[#0f7ea0] text-white px-2 py-1 rounded hover:bg-[#0c6a86] flex items-center gap-1 text-xs"
                                            data-id="<?php echo e($user->user_id); ?>"
                                            data-name="<?php echo e($user->user_name); ?>"
                                            data-email="<?php echo e($user->user_email); ?>"
                                            data-role="<?php echo e($user->user_role); ?>"
                                            data-branch="<?php echo e($user->branch_id); ?>">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                        
                                        <button onclick="viewUserDetails(this)" class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 flex items-center gap-1 text-xs"
                                            data-name="<?php echo e($user->user_name); ?>"
                                            data-email="<?php echo e($user->user_email); ?>"
                                            data-role="<?php echo e($user->user_role); ?>"
                                            data-branch="<?php echo e($user->branch->branch_name ?? 'All Branches'); ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <form action="<?php echo e(route('userManagement.destroy', $user->user_id)); ?>" method="POST"
                                            onsubmit="return confirm('Are you sure you want to delete this user?');" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="tab" value="users">
                                            <button type="submit" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 flex items-center gap-1 text-xs">
                                                <i class="fas fa-trash"></i> 
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-gray-500 py-4">No users found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if(method_exists($users, 'hasPages') && $users->hasPages()): ?>
            <div class="flex justify-between items-center mt-4 text-sm font-semibold text-black">
                <div>
                    <?php if(method_exists($users, 'firstItem')): ?>
                        Showing <?php echo e($users->firstItem()); ?> to <?php echo e($users->lastItem()); ?> of <?php echo e($users->total()); ?> entries
                    <?php else: ?>
                        Showing <?php echo e($users->count()); ?> entries
                    <?php endif; ?>
                </div>
                <div class="inline-flex border border-gray-400 rounded overflow-hidden">
                    <?php if($users->onFirstPage()): ?>
                        <button disabled class="px-3 py-1 text-gray-400 cursor-not-allowed border-r">Previous</button>
                    <?php else: ?>
                        <a href="<?php echo e($users->appends(array_merge(request()->query(), ['tab' => 'users']))->previousPageUrl()); ?>" class="px-3 py-1 text-black hover:bg-gray-200 border-r">Previous</a>
                    <?php endif; ?>

                    <?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
                        <?php if($i == $users->currentPage()): ?>
                            <button class="px-3 py-1 bg-[#0f7ea0] text-white border-r"><?php echo e($i); ?></button>
                        <?php else: ?>
                            <a href="<?php echo e($users->appends(array_merge(request()->query(), ['tab' => 'users']))->url($i)); ?>" class="px-3 py-1 hover:bg-gray-200 border-r"><?php echo e($i); ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($users->hasMorePages()): ?>
                        <a href="<?php echo e($users->appends(array_merge(request()->query(), ['tab' => 'users']))->nextPageUrl()); ?>" class="px-3 py-1 text-black hover:bg-gray-200">Next</a>
                    <?php else: ?>
                        <button disabled class="px-3 py-1 text-gray-400 cursor-not-allowed">Next</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div id="branchModal" class="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-lg p-6 rounded shadow-lg relative">
            <h2 class="text-lg font-semibold text-[#0f7ea0] mb-4" id="branchModalTitle">Add Branch</h2>
            <form id="branchForm" method="POST" action="<?php echo e(route('branches.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" id="branchFormMethod" value="POST">
                <input type="hidden" name="branch_id" id="branch_id">
                <input type="hidden" name="tab" value="branches">

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Branch Name</label>
                    <input type="text" name="name" id="branch_name" required class="w-full border rounded p-2" />
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Address</label>
                    <input type="text" name="address" id="branch_address" required class="w-full border rounded p-2" />
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Contact</label>
                    <input type="text" name="contact" id="branch_contact" required class="w-full border rounded p-2" />
                </div>

                <div class="flex justify-end space-x-2 mt-4">
                    <button type="button" onclick="closeBranchModal()"
                        class="px-4 py-1 bg-gray-300 rounded text-sm hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="px-4 py-1 bg-[#0f7ea0] text-white rounded text-sm hover:bg-[#0d6b85]">Save</button>
                </div>
            </form>
        </div>
    </div>

    
    <div id="userModal" class="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-lg p-6 rounded shadow-lg relative">
            <h2 class="text-lg font-semibold text-[#0f7ea0] mb-4" id="userModalTitle">Add User</h2>
            <form id="userForm" method="POST" action="<?php echo e(route('userManagement.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" id="userFormMethod" value="POST">
                <input type="hidden" name="user_id" id="user_id">
                <input type="hidden" name="tab" value="users">

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Full Name</label>
                    <input type="text" name="user_name" id="user_name" required class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Email</label>
                    <input type="email" name="user_email" id="user_email" required class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Password</label>
                    <input type="password" name="user_password" id="user_password" required class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Confirm Password</label>
                    <input type="password" name="user_password_confirmation" id="user_password_confirmation" required
                        class="w-full border rounded px-2 py-1 text-sm">
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Role</label>
                    <select name="user_role" id="user_role" required class="w-full border rounded px-2 py-1 text-sm">
                        <option value="">Select Role</option>
                        <option value="veterinarian">Veterinarian</option>
                        <option value="receptionist">Receptionist</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium mb-1">Branch</label>
                    <select name="branch_id" id="user_branch_id" required class="w-full border rounded px-2 py-1 text-sm">
                        <option value="">Select Branch</option>
                        <?php $__empty_1 = true; $__currentLoopData = $allBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($branch->branch_id); ?>"><?php echo e($branch->branch_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option disabled>No branches found</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="flex justify-end space-x-2 mt-4">
                    <button type="button" class="px-4 py-1 bg-gray-300 rounded text-sm hover:bg-gray-400"
                        onclick="closeUserModal()">Cancel</button>
                    <button type="submit"
                        class="px-4 py-1 bg-[#0f7ea0] text-white rounded text-sm hover:bg-[#0d6b85]">Save</button>
                </div>
            </form>
        </div>
    </div>

    
    <div id="viewBranchModal" class="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50 hidden">
        <div class="bg-white w-full max-w-lg p-6 rounded-lg shadow-lg relative">
            <div class="flex justify-between items-center border-b pb-3">
                <h2 class="text-xl font-semibold text-[#0f7ea0]">Branch Details</h2>
                <button onclick="document.getElementById('viewBranchModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
            </div>
            <div class="mt-4 space-y-3 text-sm">
                <p><strong>Branch Name:</strong> <span id="viewBranchName"></span></p>
                <p><strong>Address:</strong> <span id="viewBranchAddress"></span></p>
                <p><strong>Contact:</strong> <span id="viewBranchContact"></span></p>
            </div>
            <div class="flex justify-end mt-6">
                <button type="button" class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded text-sm" onclick="document.getElementById('viewBranchModal').classList.add('hidden')">Close</button>
            </div>
        </div>
    </div>

    
    <div id="viewUserModal" class="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50 hidden">
        <div class="bg-white w-full max-w-lg p-6 rounded-lg shadow-lg relative">
            <div class="flex justify-between items-center border-b pb-3">
                <h2 class="text-xl font-semibold text-[#0f7ea0]">User Details</h2>
                <button onclick="document.getElementById('viewUserModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
            </div>
            <div class="mt-4 space-y-3 text-sm">
                <p><strong>Name:</strong> <span id="viewUserName"></span></p>
                <p><strong>Email:</strong> <span id="viewUserEmail"></span></p>
                <p><strong>Role:</strong> <span id="viewUserRole" class="capitalize"></span></p>
                <p><strong>Branch:</strong> <span id="viewUserBranch"></span></p>
            </div>
            <div class="flex justify-end mt-6">
                <button type="button" class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded text-sm" onclick="document.getElementById('viewUserModal').classList.add('hidden')">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
.tab-button {
    border-bottom-color: transparent;
    color: #6B7280;
}

.tab-button.active {
    border-bottom-color: #0f7ea0;
    color: #0f7ea0;
}

.tab-content {
    display: block;
}

.tab-content.hidden {
    display: none;
}
</style>

<script>
// Initialize tab state on page load
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const activeTab = urlParams.get('tab') || 'branches';
    switchTab(activeTab);
});

// Tab switching functionality
function switchTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.add('hidden');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(tabName + '-content').classList.remove('hidden');
    
    // Add active class to selected tab button
    document.getElementById(tabName + '-tab').classList.add('active');
    
    // Update URL parameter without page reload
    const url = new URL(window.location);
    url.searchParams.set('tab', tabName);
    window.history.replaceState({}, '', url);
}

// Branch functionality
function openAddBranchModal() {
    const form = document.getElementById('branchForm');
    form.reset();
    form.action = `<?php echo e(route('branches.store')); ?>`;
    document.getElementById('branchFormMethod').value = 'POST';
    document.getElementById('branchModalTitle').textContent = 'Add Branch';
    document.getElementById('branchModal').classList.remove('hidden');
}

function closeBranchModal() {
    document.getElementById('branchModal').classList.add('hidden');
}

function viewBranchDetails(button) {
    document.getElementById('viewBranchName').innerText = button.dataset.name;
    document.getElementById('viewBranchAddress').innerText = button.dataset.address;
    document.getElementById('viewBranchContact').innerText = button.dataset.contact;
    document.getElementById('viewBranchModal').classList.remove('hidden');
}

// Edit branch functionality
document.querySelectorAll('.editBranchBtn').forEach(button => {
    button.addEventListener('click', () => {
        document.getElementById('branchForm').reset();

        document.getElementById('branch_id').value = button.dataset.id;
        document.getElementById('branch_name').value = button.dataset.name;
        document.getElementById('branch_address').value = button.dataset.address;
        document.getElementById('branch_contact').value = button.dataset.contact;

        const branchId = button.dataset.id;
        document.getElementById('branchForm').action = `/branches/${branchId}`;
        document.getElementById('branchFormMethod').value = 'PUT';
        document.getElementById('branchModalTitle').textContent = 'Edit Branch';

        document.getElementById('branchModal').classList.remove('hidden');
    });
});

// User functionality
function openAddUserModal() {
    const form = document.getElementById('userForm');
    form.reset();
    form.action = `<?php echo e(route('userManagement.store')); ?>`;
    document.getElementById('userFormMethod').value = 'POST';
    document.getElementById('userModalTitle').textContent = 'Add User';
    
    // Make password fields required for new users
    document.getElementById('user_password').required = true;
    document.getElementById('user_password_confirmation').required = true;
    
    document.getElementById('userModal').classList.remove('hidden');
}

function closeUserModal() {
    document.getElementById('userModal').classList.add('hidden');
}

function viewUserDetails(button) {
    document.getElementById('viewUserName').innerText = button.dataset.name;
    document.getElementById('viewUserEmail').innerText = button.dataset.email;
    document.getElementById('viewUserRole').innerText = button.dataset.role;
    document.getElementById('viewUserBranch').innerText = button.dataset.branch;
    document.getElementById('viewUserModal').classList.remove('hidden');
}

// Edit user functionality
document.querySelectorAll('.editUserBtn').forEach(button => {
    button.addEventListener('click', () => {
        document.getElementById('userForm').reset();

        document.getElementById('user_id').value = button.dataset.id;
        document.getElementById('user_name').value = button.dataset.name;
        document.getElementById('user_email').value = button.dataset.email;
        document.getElementById('user_role').value = button.dataset.role;
        document.getElementById('user_branch_id').value = button.dataset.branch;

        // Make password fields optional for editing
        document.getElementById('user_password').required = false;
        document.getElementById('user_password_confirmation').required = false;

        const userId = button.dataset.id;
        document.getElementById('userForm').action = `/user-management/${userId}`;
        document.getElementById('userFormMethod').value = 'PUT';
        document.getElementById('userModalTitle').textContent = 'Edit User';

        document.getElementById('userModal').classList.remove('hidden');
    });
});

// Close modals when clicking outside
document.querySelectorAll('.fixed').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.add('hidden');
        }
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Multi-branchVCMS\MBVCMS\resources\views/branchUserManagement.blade.php ENDPATH**/ ?>