

<?php $__env->startSection('content'); ?>
<div class="min-h-screen">
    <div class="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-[#0f7ea0] font-bold text-xl">Orders</h2>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-700 px-4 py-2 mb-4 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Orders Table -->
        <table class="table-auto w-full border-collapse border text-sm text-center">
            <thead class="bg-gray-200">
                <tr>
                    <th class="border px-4 py-2">#</th>
                    <th class="border px-4 py-2">Order Date</th>
                    <th class="border px-4 py-2">Product</th>
                    <th class="border px-4 py-2">Quantity</th>
                    <th class="border px-4 py-2">Price</th>
                    <th class="border px-4 py-2">Subtotal</th>
                    <th class="border px-4 py-2">Ordered By</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($orders->firstItem() + $index); ?></td>
                        <td class="border px-4 py-2"><?php echo e($order->ord_date); ?></td>
                        <td class="border px-4 py-2"><?php echo e($order->product->prod_name ?? 'N/A'); ?></td>
                        <td class="border px-4 py-2"><?php echo e($order->ord_quantity); ?></td>
                        <td class="border px-4 py-2">₱<?php echo e(number_format($order->product->prod_price ?? 0, 2)); ?></td>
                        <td class="border px-4 py-2">₱<?php echo e(number_format(($order->product->prod_price ?? 0) * $order->ord_quantity, 2)); ?></td>
                        <td class="border px-4 py-2"><?php echo e($order->user->user_name ?? 'N/A'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="py-4 text-gray-500">No orders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\OneDrive\Desktop\Multi-branchVCMS\MBVCMS\resources\views/order.blade.php ENDPATH**/ ?>