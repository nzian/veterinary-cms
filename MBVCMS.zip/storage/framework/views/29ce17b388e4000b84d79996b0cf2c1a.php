<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <title>Multi-Branch VCMS Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Inter', sans-serif;
      margin: 0;
      height: 100vh;
    }

    /* Custom scrollbar */
    ::-webkit-scrollbar {
      width: 6px;
    }

    ::-webkit-scrollbar-track {
      background: #f1f5f9;
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 3px;
    }

    ::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }

    /* Modern glassmorphism effect */
    .glass-card {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    /* Smooth transitions */
    .smooth-transition {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* Modern gradient background */
    .gradient-bg {
      background: linear-gradient(135deg, #0f7ea0 0%, #0c6b87 50%, #0a5a73 100%);
    }

    /* Hover effects */
    .hover-lift {
      transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }

    .hover-lift:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    }

    /* Modern button style */
    .modern-btn {
      position: relative;
      overflow: hidden;
    }

    .modern-btn::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transition: left 0.5s;
    }

    .modern-btn:hover::before {
      left: 100%;
    }

    /* Custom notification badge */
    .notification-badge {
      position: absolute;
      top: -2px;
      right: -2px;
      background: #ef4444;
      color: white;
      border-radius: 50%;
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: 600;
      animation: pulse 2s infinite;
    }

    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.1); }
      100% { transform: scale(1); }
    }

    /* Modern dropdown styling */
    .modern-dropdown {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(0, 0, 0, 0.1);
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }

    /* Sidebar modern styling */
    .sidebar-item {
      position: relative;
      overflow: hidden;
    }

    .sidebar-item::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      height: 100%;
      width: 4px;
      background: #0f7ea0;
      transform: scaleY(0);
      transition: transform 0.3s ease;
    }

    .sidebar-item.active::before,
    .sidebar-item:hover::before {
      transform: scaleY(1);
    }

    .sidebar-item.active {
      background: linear-gradient(90deg, rgba(15, 126, 160, 0.2), transparent);
    }

    /* Search input modern styling */
    .modern-search {
      background: rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(10px);
    }

    .modern-search:focus {
      background: rgba(255, 255, 255, 1);
      border-color: rgba(15, 126, 160, 0.5);
      outline: none;
      box-shadow: 0 0 0 3px rgba(15, 126, 160, 0.1);
    }
  </style>
</head>

<body class="h-screen flex flex-col bg-gradient-to-br from-gray-50 to-gray-100">
  <!-- HEADER -->
  <header class="flex items-center h-16 gradient-bg text-white shadow-xl relative z-50">
    
    <!-- Logo Section -->
    <div class="h-full flex items-center justify-center bg-white w-16 md:w-64 shrink-0">
      <img src="<?php echo e(asset('images/MultiBranchVCMS.jpg')); ?>"
           class="h-10 md:h-11 object-contain w-full"
           alt="Logo" />
    </div>

    <!-- Branch Selector -->
    <div class="flex-shrink-0 relative ml-4">
      <button id="branchDropdownBtn" class="flex items-center gap-2 px-4 py-2 rounded-lg hover-lift modern-btn bg-white/10 backdrop-blur-sm hover:bg-white/20 smooth-transition">
        <i class="fas fa-code-branch text-lg"></i>
        <span class="hidden md:inline font-medium">
          Branches <i class="fas fa-chevron-down ml-2 text-sm"></i>
        </span>
      </button>

      <!-- Branch Dropdown -->
      <div id="branchDropdownMenu" class="hidden absolute mt-3 modern-dropdown rounded-xl w-48 z-50 overflow-hidden">
        <div class="py-2">
          <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('branch.switch', ['id' => $branch->branch_id])); ?>"
               data-branch="<?php echo e($branch->branch_id); ?>"
               class="branch-link block px-4 py-3 text-sm font-medium text-gray-700 hover:bg-[#0f7ea0] hover:text-white smooth-transition border-l-4 border-transparent hover:border-[#0f7ea0]">
              <i class="fas fa-building mr-3 text-xs opacity-70"></i>
              <?php echo e($branch->branch_name); ?>

            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>

    <!-- Search Section -->
    <form method="GET" action="<?php echo e(route('pets-index')); ?>" class="flex-1 mx-6 relative">
      <div class="relative group">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>"
          class="w-full h-11 rounded-xl modern-search px-4 pr-12 text-sm text-gray-700 placeholder:text-gray-400 smooth-transition"
          placeholder="Search pets, owners, appointments..." />
        <button type="submit" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-[#0f7ea0] smooth-transition">
          <i class="fas fa-search text-lg"></i>
        </button>
        <div class="absolute inset-0 rounded-xl bg-gradient-to-r from-[#0f7ea0]/20 to-transparent opacity-0 group-hover:opacity-100 smooth-transition pointer-events-none"></div>
      </div>
    </form>

    <!-- Notifications -->
    <div class="relative mr-4">
      <button class="flex items-center justify-center w-11 h-11 rounded-xl bg-white/10 backdrop-blur-sm hover:bg-white/20 smooth-transition hover-lift modern-btn relative" onclick="toggleNotificationDropdown()">
        <i class="fas fa-bell text-lg"></i>
        <?php if(!empty($lowStockItems)): ?>
          <span class="notification-badge"><?php echo e(count($lowStockItems)); ?></span>
        <?php endif; ?>
      </button>

      <div id="notificationDropdown" class="hidden absolute right-0 mt-3 w-80 modern-dropdown rounded-xl z-50 overflow-hidden">
        <div class="px-4 py-3 bg-gradient-to-r from-[#0f7ea0] to-[#0c6b87] text-white">
          <h3 class="font-semibold text-sm">Notifications</h3>
          <p class="text-xs opacity-90">Stock alerts and updates</p>
        </div>
        <div class="max-h-64 overflow-y-auto">
          <?php $__empty_1 = true; $__currentLoopData = $lowStockItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="px-4 py-3 border-b border-gray-100 hover:bg-gray-50 smooth-transition">
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                  <i class="fas fa-exclamation-triangle text-red-500 text-sm"></i>
                </div>
                <div class="flex-1">
                  <p class="font-medium text-sm text-gray-900"><?php echo e($item->prod_name); ?></p>
                  <p class="text-xs text-gray-500">Only <?php echo e($item->prod_stocks); ?> items left</p>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="px-4 py-8 text-center text-gray-500">
              <i class="fas fa-check-circle text-2xl mb-2"></i>
              <p class="text-sm">No alerts at the moment</p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- POS Button -->
    <a href="<?php echo e(route('pos')); ?>" class="mr-4">
      <button class="bg-gradient-to-r from-[#8bc34a] to-[#7cb342] text-white font-semibold px-6 py-2.5 rounded-xl hover-lift modern-btn shadow-lg hover:shadow-xl smooth-transition">
        <i class="fas fa-cash-register mr-2"></i>
        <span class="hidden sm:inline">POS</span>
      </button>
    </a>

    <!-- User Dropdown -->
    <div class="relative mr-4">
      <button class="flex items-center gap-3 px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm hover:bg-white/20 smooth-transition hover-lift modern-btn" onclick="toggleUserDropdown()">
        <div class="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
          <i class="fas fa-user text-sm"></i>
        </div>
        <div class="hidden md:block text-left">
          <p class="text-xs font-medium">
            <?php if(auth()->guard()->check()): ?>
              <?php echo e(auth()->user()->user_role === 'Super Admin' ? 'Welcome Admin' : ucwords(auth()->user()->user_role)); ?>

            <?php endif; ?>
          </p>
        </div>
        <i class="fas fa-chevron-down text-xs opacity-70"></i>
      </button>

      <div id="userDropdown" class="hidden absolute right-0 mt-3 w-48 modern-dropdown rounded-xl z-50 overflow-hidden">
        <div class="py-2">
          <a href="<?php echo e(route('logout')); ?>"
             onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
             class="flex items-center gap-3 px-4 py-3 text-sm font-medium text-gray-700 hover:bg-red-50 hover:text-red-600 smooth-transition">
            <i class="fas fa-sign-out-alt"></i>
            Logout
          </a>
        </div>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
          <?php echo csrf_field(); ?>
        </form>
      </div>
    </div>
  </header>

  <!-- SIDEBAR + MAIN WRAPPER -->
  <div class="flex flex-1 overflow-hidden">
    <!-- SIDEBAR -->
    <aside class="bg-gradient-to-b from-slate-800 to-slate-900 w-16 md:w-64 flex flex-col shadow-2xl relative">
      <!-- Navigation -->
      <nav class="flex-1 py-6">
        <ul class="space-y-1 px-3">
          <!-- Dashboard -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'dashboard-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('dashboard-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-tachometer-alt text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Dashboard</span>
            </a>
          </li>

          <!-- Pet Owners -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'owners-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('owners-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-user-alt text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Pet Owners</span>
            </a>
          </li>

          <!-- Pets -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'pets-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('pets-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-paw text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Pets</span>
            </a>
          </li>

          <!-- Appointments -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'appointments-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('appointments-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-calendar-alt text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Appointments</span>
            </a>
          </li>

          <!-- Referrals -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'referral-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('referral-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-share text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Referrals</span>
            </a>
          </li>

          <!-- Billings -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'billing-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('billing-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-receipt text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Billings</span>
            </a>
          </li>

          <!-- Products -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'product-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('product-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-box-open text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Products</span>
            </a>
          </li>

          <!-- Services -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'services-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('services-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-hand-holding-medical text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Services</span>
            </a>
          </li>

          <!-- Orders -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'order-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('order-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-clipboard-list text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Orders</span>
            </a>
          </li>

          <!-- Branches -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'branches-index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('branches-index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-code-branch text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Branches</span>
            </a>
          </li>

          <!-- Users -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'userManagement.index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('userManagement.index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-users text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Users</span>
            </a>
          </li>

          <!-- Reports -->
          <li class="sidebar-item <?php echo e(Route::currentRouteName() == 'report.index' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('report.index')); ?>" class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
                <i class="fas fa-chart-bar text-lg"></i>
              </div>
              <span class="hidden md:inline font-medium">Reports</span>
            </a>
          </li>
        </ul>
      </nav>

      <!-- Settings -->
      <div class="p-3 border-t border-white/10">
        <button class="flex items-center gap-4 px-4 py-3 text-white hover:text-white smooth-transition rounded-xl group w-full hover:bg-white/10">
          <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center group-hover:bg-[#0f7ea0] smooth-transition">
            <i class="fas fa-cog text-lg"></i>
          </div>
          <span class="hidden md:inline font-medium">Settings</span>
        </button>
      </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100 relative">
      <!-- Main content container -->
      <div class="p-6 h-full">
        <!-- Content area with modern card styling -->
        <div>
          <?php echo $__env->yieldContent('content'); ?>
        </div>
      </div>
    </main>
  </div>
  
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Branch dropdown functionality
      const btn = document.getElementById('branchDropdownBtn');
      const menu = document.getElementById('branchDropdownMenu');

      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        menu.classList.toggle('hidden');
      });

      // Close dropdowns when clicking outside
      document.addEventListener('click', function (e) {
        if (!e.target.closest('#branchDropdownBtn')) {
          menu.classList.add('hidden');
        }
        if (!e.target.closest('#notificationDropdown') && !e.target.closest('[onclick="toggleNotificationDropdown()"]')) {
          document.getElementById('notificationDropdown').classList.add('hidden');
        }
        if (!e.target.closest('#userDropdown') && !e.target.closest('[onclick="toggleUserDropdown()"]')) {
          document.getElementById('userDropdown').classList.add('hidden');
        }
      });

      // Add loading states for navigation items
      const navLinks = document.querySelectorAll('nav a');
      navLinks.forEach(link => {
        link.addEventListener('click', function() {
          const icon = this.querySelector('i');
          const originalClass = icon.className;
          icon.className = 'fas fa-spinner fa-spin text-lg';
          
          setTimeout(() => {
            icon.className = originalClass;
          }, 500);
        });
      });
    });

    function toggleNotificationDropdown() {
      document.getElementById('notificationDropdown').classList.toggle('hidden');
    }

    function toggleUserDropdown() {
      document.getElementById('userDropdown').classList.toggle('hidden');
    }

    // Add smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';
  </script>
</body>

</html><?php /**PATH C:\Users\USER\OneDrive\Desktop\Multi-branchVCMS\MBVCMS\resources\views/AdminBoard.blade.php ENDPATH**/ ?>