

<?php $__env->startSection('content'); ?>
    <div class="">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

 <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-700 px-4 py-2 mb-4 rounded text-sm">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        
        <div class="bg-white rounded-2xl shadow p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-[#0f7ea0] font-bold text-xl">Billing Management</h2>
            </div>

           


            
            <div class="overflow-x-auto">
                <table class="w-full table-auto text-sm border text-center">
                    <thead>
                        <tr class="bg-gray-100 text-centered">
                            <th class="px-4 py-2 border">Owner</th>
                            <th class="px-4 py-2 border">Services</th>
                            <th class="px-4 py-2 border">Date</th>
                            <th class="px-4 py-2 border">Status</th>
                            <th class="px-4 py-2 border text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $billings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 border">
                                    <?php echo e($billing->appointment?->pet?->owner?->own_name ?? 'N/A'); ?>

                                </td>
                                <td class="px-4 py-2 border">
                                    <?php if($billing->appointment && $billing->appointment->services && $billing->appointment->services->count() > 0): ?>
                                        <?php
                                            $total = 0;
                                        ?>
                                        <?php $__currentLoopData = $billing->appointment->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $total += $service->serv_price ?? 0;
                                            ?>
                                            <span class="block">
                                                <?php echo e($service->serv_name ?? 'N/A'); ?> - ₱<?php echo e(number_format($service->serv_price ?? 0, 2)); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="font-bold mt-1 pt-1 border-t">
                                            Total: ₱<?php echo e(number_format($total, 2)); ?>

                                        </div>
                                    <?php else: ?>
                                        <span class="text-gray-500">No services</span>
                                        <?php $total = $billing->bill_total ?? 0; ?>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-2 border"><?php echo e($billing->bill_date); ?></td>
                                <td class="px-4 py-2 border text-center">
                                    <?php if($billing->bill_status === 'Paid'): ?>
                                        <span class="text-green-600 font-semibold">Paid</span>
                                    <?php else: ?>
                                        <span class="text-red-600 font-semibold">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-2 border text-center">
    <div class="flex justify-center items-center gap-1">
         <?php if($billing->bill_status !== 'Paid'): ?>
            <button
                class="bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700 flex items-center gap-1 text-xs payBillingBtn"
                data-bill-id="<?php echo e($billing->bill_id); ?>"
                data-bill-total="<?php echo e($total ?? 0); ?>">
                <i class="fas fa-dollar-sign"></i> Pay
            </button>
        <?php endif; ?>
        <button
            class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 flex items-center gap-1 text-xs"
            onclick="openBillModal(<?php echo e($billing->bill_id); ?>)">
            <i class="fas fa-eye"></i> View
        </button>

        <form method="POST" action="<?php echo e(route('billings.destroy', $billing->bill_id)); ?>"
              onsubmit="return confirm('Are you sure you want to delete this billing?');"
              class="inline-block">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit"
                    class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 flex items-center gap-1 text-xs">
                <i class="fas fa-trash"></i> Delete
            </button>
        </form>
    </div>
</td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-4 py-2 border text-center text-gray-500">
                                    No billing records found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="mt-4">
                <?php echo e($billings->links()); ?>

            </div>
        </div>
    </div>

    
    <div id="billModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
        <div class="bg-white rounded-2xl shadow-lg p-6 w-1/2">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-bold">Billing Details</h3>
                <button onclick="closeBillModal()" class="text-gray-500 hover:text-gray-700">&times;</button>
            </div>
            <div id="billDetails" class="space-y-3"></div>
            <div class="mt-4 text-right">
                <button onclick="closeBillModal()" class="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400">Close</button>
            </div>
        </div>
    </div>

    
    <div id="billingPaymentModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-4 w-80 shadow-lg">
            <h2 class="text-lg font-semibold mb-2 text-center">Enter Payment</h2>

            <div class="mb-2">
                <label class="block text-sm">Total Amount</label>
                <div id="billingTotal" class="text-lg font-bold">₱0.00</div>
            </div>

            <div class="mb-2">
                <label for="billingCash" class="block text-sm">Cash</label>
                <input type="number" id="billingCash" class="w-full border px-2 py-1 rounded" min="0" />
            </div>

            <div class="mb-4">
                <label class="block text-sm">Change</label>
                <div id="billingChange" class="text-lg font-bold text-green-600">₱0.00</div>
            </div>

            <div class="flex justify-end gap-2">
                <button id="cancelBillingPayment" class="px-3 py-1 bg-gray-400 text-white rounded text-sm">Cancel</button>
                <button id="confirmBillingPayment"
                    class="px-3 py-1 bg-green-600 text-white rounded text-sm">Confirm</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Open Pay Modal
            document.querySelectorAll('.payBillingBtn').forEach(btn => {
                btn.addEventListener('click', function () {
                    const billId = this.dataset.billId;
                    const total = parseFloat(this.dataset.billTotal) || 0;

                    console.log('Opening payment modal for bill:', billId, 'total:', total);

                    document.getElementById('billingPaymentModal').classList.remove('hidden');
                    document.getElementById('confirmBillingPayment').dataset.billId = billId;
                    document.getElementById('billingTotal').textContent = `₱${total.toFixed(2)}`;
                    document.getElementById('billingCash').value = '';
                    document.getElementById('billingChange').textContent = '₱0.00';
                });
            });

            // Calculate change dynamically
            document.getElementById('billingCash').addEventListener('input', () => {
                const total = parseFloat(document.getElementById('billingTotal').textContent.replace("₱", "")) || 0;
                const cash = parseFloat(document.getElementById('billingCash').value) || 0;
                const change = cash - total;
                document.getElementById('billingChange').textContent = change >= 0 ? `₱${change.toFixed(2)}` : '₱0.00';
            });

            // Cancel button
            document.getElementById('cancelBillingPayment').addEventListener('click', () => {
                document.getElementById('billingPaymentModal').classList.add('hidden');
            });

            // Confirm payment - IMPROVED WITH BETTER ERROR HANDLING
            document.getElementById('confirmBillingPayment').addEventListener('click', function () {
                const billId = this.dataset.billId;
                const cash = parseFloat(document.getElementById('billingCash').value) || 0;
                const total = parseFloat(document.getElementById('billingTotal').textContent.replace("₱", "")) || 0;

                console.log('Payment attempt:', { billId, cash, total });

                if (cash < total) {
                    alert("Cash is not enough!");
                    return;
                }

                if (!billId) {
                    alert("Bill ID is missing!");
                    return;
                }

                // Show loading state
                this.textContent = 'Processing...';
                this.disabled = true;

                fetch(`/billing/pay/${billId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        cash: cash,
                        total: total
                    })
                })
                    .then(response => {
                        console.log('Response status:', response.status);
                        console.log('Response ok:', response.ok);

                        // Check if response is ok
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }

                        return response.json();
                    })
                    .then(data => {
                        console.log('Payment response:', data);

                        if (data.success) {
                            alert(data.message);
                            document.getElementById('billingPaymentModal').classList.add('hidden');
                            location.reload();
                        } else {
                            alert(data.message || "Payment failed!");
                        }
                    })
                    .catch(error => {
                        console.error('Payment error details:', error);
                        alert(`Payment failed: ${error.message}`);
                    })
                    .finally(() => {
                        // Reset button state
                        this.textContent = 'Confirm';
                        this.disabled = false;
                    });
            });
        });

        // Bill modal
        function openBillModal(billId) {
            fetch(`/billing/${billId}`)
                .then(res => res.json())
                .then(data => {
                    let servicesHtml = '';
                    if (data.services && data.services.length > 0) {
                        data.services.forEach(service => {
                            const price = parseFloat(service.serv_price || 0);
                            servicesHtml += `<div>${service.serv_name || 'Unknown Service'} - ₱${price.toFixed(2)}</div>`;
                        });
                    } else {
                        servicesHtml = '<div class="text-gray-500">No services</div>';
                    }

                    const total = parseFloat(data.total || 0);
                    const cash = parseFloat(data.billing.bill_cash || 0);
                    const change = parseFloat(data.billing.bill_change || 0);

                    document.getElementById('billDetails').innerHTML = `
                    <div><strong>Owner:</strong> ${data.owner || 'N/A'}</div>
                    <div><strong>Date:</strong> ${data.billing.bill_date || 'N/A'}</div>
                    <div><strong>Status:</strong> <span class="${data.billing.bill_status === 'Paid' ? 'text-green-600' : 'text-red-600'} font-semibold">${data.billing.bill_status || 'Pending'}</span></div>
                    <div><strong>Services:</strong></div>
                    <div class="ml-4">${servicesHtml}</div>
                    <div class="mt-2"><strong>Total:</strong> ₱${total.toFixed(2)}</div>
                    ${data.billing.bill_status === 'Paid' ? `
                        <div><strong>Cash:</strong> ₱${cash.toFixed(2)}</div>
                        <div><strong>Change:</strong> ₱${change.toFixed(2)}</div>
                    ` : ''}
                `;
                    document.getElementById('billModal').classList.remove('hidden');
                })
                .catch(err => {
                    console.error(err);
                    document.getElementById('billDetails').innerHTML = "Error loading billing details.";
                    document.getElementById('billModal').classList.remove('hidden');
                });
        }

        function closeBillModal() {
            document.getElementById('billModal').classList.add('hidden');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\OneDrive\Desktop\Multi-branchVCMS\MBVCMS\resources\views/billing.blade.php ENDPATH**/ ?>