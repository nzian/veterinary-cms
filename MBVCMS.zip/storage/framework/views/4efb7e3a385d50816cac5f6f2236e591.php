

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
  <div class="max-w-7xl mx-auto p-6">

    
    <div class="flex justify-between items-center mb-8">
      <div>
        <h1 class="text-3xl font-bold text-[#0f7ea0]"><?php echo e($branchName); ?></h1>
        <p class="text-gray-600 mt-1">Dashboard Overview</p>
      </div>
      <div class="text-sm text-gray-500">
        <?php echo e(date('l, F j, Y')); ?>

      </div>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <?php
        $keyMetrics = [
          [
            'label' => 'Total Appointments', 
            'value' => $totalAppointments,
            'icon' => '📅',
            'color' => 'from-blue-500 to-blue-600',
            'change' => '+12%'
          ],
          [
            'label' => "Today's Appointments", 
            'value' => $todaysAppointments,
            'icon' => '🕒',
            'color' => 'from-emerald-500 to-emerald-600',
            'change' => '+8%'
          ],
          [
            'label' => 'Total Pet Owners', 
            'value' => $totalOwners,
            'icon' => '👥',
            'color' => 'from-purple-500 to-purple-600',
            'change' => '+5%'
          ],
          [
            'label' => 'Daily Revenue', 
            'value' => '₱' . number_format($dailySales, 2),
            'icon' => '💰',
            'color' => 'from-amber-500 to-amber-600',
            'change' => '+15%'
          ],
        ];
      ?>

      <?php $__currentLoopData = $keyMetrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="relative overflow-hidden bg-white rounded-2xl shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300 group">
          <div class="absolute inset-0 bg-gradient-to-br <?php echo e($metric['color']); ?> opacity-0 group-hover:opacity-5 transition-opacity"></div>
          <div class="p-6">
            <div class="flex items-center justify-between mb-4">
              <div class="text-2xl"><?php echo e($metric['icon']); ?></div>
              <span class="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">
                <?php echo e($metric['change']); ?>

              </span>
            </div>
            <div class="space-y-1">
              <p class="text-sm font-medium text-gray-600"><?php echo e($metric['label']); ?></p>
              <p class="text-2xl font-bold text-gray-900"><?php echo e($metric['value']); ?></p>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      
      
      <div class="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-200">
        <div class="p-6">
          <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-semibold text-gray-900">Appointment Calendar</h2>
            <div class="flex items-center space-x-2">
              <button id="monthlyBtn" class="px-3 py-1.5 text-sm font-medium text-white bg-blue-500 rounded-lg hover:bg-[#0f7ea0 transition-colors">Monthly</button>
              <button id="weeklyBtn" class="px-3 py-1.5 text-sm font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">Weekly</button>
              <button id="todayBtn" class="px-3 py-1.5 text-sm font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">Today</button>
              <div class="flex space-x-1 ml-2">
                <button id="prevBtn" class="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">←</button>
                <button id="nextBtn" class="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">→</button>
              </div>
            </div>
          </div>
          
          <div id="calendar">
            <div id="calendarHeader" class="text-lg font-semibold text-gray-900 text-center mb-4"></div>
            <div class="overflow-hidden rounded-lg border border-gray-200">
              <table class="w-full">
                <thead>
                  <tr class="bg-gray-50 border-b border-gray-200">
                    <?php $__currentLoopData = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <th class="px-3 py-3 text-sm font-medium text-gray-700 text-center"><?php echo e($day); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tr>
                </thead>
                <tbody id="calendarBody" class="divide-y divide-gray-200"></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      
      <div class="space-y-6">
        
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h3 class="text-lg font-semibold text-gray-900 mb-4">Today's Summary</h3>
          <div class="space-y-3">
            <div class="flex justify-between items-center">
              <span class="text-sm text-gray-600">Appointments</span>
              <span class="text-sm font-semibold text-gray-900"><?php echo e($todaysAppointments); ?></span>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-sm text-gray-600">Revenue</span>
              <span class="text-sm font-semibold text-green-600">₱<?php echo e(number_format($dailySales, 2)); ?></span>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-sm text-gray-600">Active Pets</span>
              <span class="text-sm font-semibold text-gray-900"><?php echo e($totalPets); ?></span>
            </div>
          </div>
        </div>

        
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
          <h3 class="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div class="space-y-3">
            <button class="w-full px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
              Add Appointment
            </button>
            <button class="w-full px-4 py-2 text-sm font-medium text-emerald-600 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors">
              New Pet Owner
            </button>
            <button class="w-full px-4 py-2 text-sm font-medium text-purple-600 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
              View Reports
            </button>
          </div>
        </div>
      </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      
      <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-semibold text-gray-900">Daily Revenue</h3>
          <span class="text-sm text-gray-500">Last 7 days</span>
        </div>
        <div class="h-64">
          <canvas id="dailyOrdersChart"></canvas>
        </div>
      </div>
      
      
      <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-lg font-semibold text-gray-900">Monthly Overview</h3>
          <span class="text-sm text-gray-500">This year</span>
        </div>
        <div class="h-64">
          <canvas id="monthlyOrdersChart"></canvas>
        </div>
      </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      
      <div class="bg-white rounded-2xl shadow-sm border border-gray-200">
        <div class="px-6 py-4 border-b border-gray-200">
          <h3 class="text-lg font-semibold text-gray-900">Recent Appointments</h3>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pet</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <?php $__currentLoopData = $recentAppointments->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-sm text-gray-900"><?php echo e($appointment->appoint_date); ?></td>
                  <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($appointment->pet?->pet_name ?? 'N/A'); ?></td>
                  <td class="px-6 py-4">
                    <?php
                      $statusColors = [
                        'approved' => 'bg-green-100 text-green-800',
                        'pending' => 'bg-yellow-100 text-yellow-800',
                        'arrive' => 'bg-blue-100 text-blue-800',
                        'rescheduled' => 'bg-orange-100 text-orange-800'
                      ];
                      $status = strtolower($appointment->appoint_status);
                      $colorClass = $statusColors[$status] ?? 'bg-gray-100 text-gray-800';
                    ?>
                    <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?php echo e($colorClass); ?>">
                      <?php echo e(ucfirst($appointment->appoint_status)); ?>

                    </span>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

      
      <div class="bg-white rounded-2xl shadow-sm border border-gray-200">
        <div class="px-6 py-4 border-b border-gray-200">
          <h3 class="text-lg font-semibold text-gray-900">Recent Referrals</h3>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <?php $__currentLoopData = $recentReferrals->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-sm text-gray-900"><?php echo e($ref->ref_date); ?></td>
                  <td class="px-6 py-4 text-sm text-gray-600"><?php echo e(Str::limit($ref->ref_description, 30)); ?></td>
                  <td class="px-6 py-4">
                    <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                      <?php echo e(ucfirst($ref->ref_status ?? 'Pending')); ?>

                    </span>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  const appointments = <?php echo $appointments->toJson(); ?>;
  let viewDate = new Date();
  let currentView = 'monthly';

  const calendarHeader = document.getElementById('calendarHeader');
  const calendarBody = document.getElementById('calendarBody');

  function formatDate(date) {
    return date.toISOString().split('T')[0];
  }

  function getStatusColor(status) {
    const colors = {
      'arrive': 'bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full',
      'pending': 'bg-yellow-100 text-yellow-700 text-xs px-2 py-1 rounded-full',
      'rescheduled': 'bg-orange-100 text-orange-700 text-xs px-2 py-1 rounded-full',
      'approved': 'bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full'
    };
    return colors[(status || '').toLowerCase()] || 'bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full';
  }

  function updateViewButtons(activeView) {
    const buttons = ['monthlyBtn', 'weeklyBtn', 'todayBtn'];
    buttons.forEach(id => {
      const btn = document.getElementById(id);
      if (id.replace('Btn', '') === activeView) {
        btn.className = 'px-3 py-1.5 text-sm font-medium text-white bg-blue-500 rounded-lg hover:bg-blue-600 transition-colors';
      } else {
        btn.className = 'px-3 py-1.5 text-sm font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors';
      }
    });
  }

  function renderCalendar(view) {
    calendarBody.innerHTML = '';
    currentView = view;
    updateViewButtons(view);

    if (view === 'monthly') {
      calendarHeader.textContent = viewDate.toLocaleString('default', { month: 'long', year: 'numeric' });
      const firstDay = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1);
      const lastDay = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0);
      const startDay = firstDay.getDay();
      const totalDays = lastDay.getDate();

      let day = 1;
      for (let row = 0; row < 6; row++) {
        let html = '<tr>';
        for (let i = 0; i < 7; i++) {
          if ((row === 0 && i < startDay) || day > totalDays) {
            html += `<td class="p-3 h-24 align-top border-t border-gray-200"></td>`;
          } else {
            const dateObj = new Date(viewDate.getFullYear(), viewDate.getMonth(), day);
            const dateStr = formatDate(dateObj);
            const events = appointments[dateStr] || [];

            let eventsHTML = '';
            events.slice(0, 2).forEach(event => {
              const colorClass = getStatusColor(event.status);
              eventsHTML += `<div class="mb-1"><span class="${colorClass}">${event.title.substring(0, 10)}...</span></div>`;
            });
            if (events.length > 2) {
              eventsHTML += `<div class="text-xs text-gray-500">+${events.length - 2} more</div>`;
            }

            const isToday = formatDate(new Date()) === dateStr;
            const bgClass = isToday ? 'bg-blue-50' : '';

            html += `<td class="p-3 h-24 align-top border-t border-gray-200 ${bgClass} hover:bg-gray-50 transition-colors">
                      <div class="font-medium text-sm mb-1 ${isToday ? 'text-blue-600' : 'text-gray-900'}">${day}</div>
                      <div>${eventsHTML}</div>
                    </td>`;
            day++;
          }
        }
        html += '</tr>';
        calendarBody.innerHTML += html;
        if (day > totalDays) break;
      }
    }

    else if (view === 'weekly') {
      calendarHeader.textContent = 'Week of ' + viewDate.toLocaleDateString();
      const weekStart = new Date(viewDate);
      weekStart.setDate(viewDate.getDate() - viewDate.getDay());

      let row = '<tr>';
      for (let i = 0; i < 7; i++) {
        const date = new Date(weekStart);
        date.setDate(weekStart.getDate() + i);
        const dateStr = formatDate(date);
        const events = appointments[dateStr] || [];

        let eventsHTML = '';
        events.forEach(event => {
          const colorClass = getStatusColor(event.status);
          eventsHTML += `<div class="mb-1"><span class="${colorClass}">${event.title}</span></div>`;
        });

        const isToday = formatDate(new Date()) === dateStr;
        const bgClass = isToday ? 'bg-blue-50' : '';

        row += `<td class="p-4 align-top border-t border-gray-200 ${bgClass} hover:bg-gray-50 transition-colors">
                  <div class="font-medium mb-2 ${isToday ? 'text-blue-600' : 'text-gray-900'}">${date.getDate()}</div>
                  <div>${eventsHTML}</div>
                </td>`;
      }
      row += '</tr>';
      calendarBody.innerHTML = row;
    }

    else if (view === 'today') {
      calendarHeader.textContent = viewDate.toDateString();
      const todayStr = formatDate(viewDate);
      const events = appointments[todayStr] || [];

      let html = `<tr><td class="p-6 border-t border-gray-200" colspan="7">`;
      if (events.length) {
        html += '<div class="space-y-3">';
        events.forEach(event => {
          const colorClass = getStatusColor(event.status);
          html += `<div class="flex items-center space-x-3">
                    <span class="${colorClass}">${event.title}</span>
                  </div>`;
        });
        html += '</div>';
      } else {
        html += '<div class="text-center text-gray-500 py-8">No appointments today</div>';
      }
      html += `</td></tr>`;
      calendarBody.innerHTML = html;
    }
  }

  // Event Listeners
  document.getElementById('monthlyBtn').onclick = () => renderCalendar('monthly');
  document.getElementById('weeklyBtn').onclick = () => renderCalendar('weekly');
  document.getElementById('todayBtn').onclick = () => renderCalendar('today');
  
  document.getElementById('prevBtn').onclick = () => {
    if (currentView === 'monthly') viewDate.setMonth(viewDate.getMonth() - 1);
    if (currentView === 'weekly') viewDate.setDate(viewDate.getDate() - 7);
    if (currentView === 'today') viewDate.setDate(viewDate.getDate() - 1);
    renderCalendar(currentView);
  };
  
  document.getElementById('nextBtn').onclick = () => {
    if (currentView === 'monthly') viewDate.setMonth(viewDate.getMonth() + 1);
    if (currentView === 'weekly') viewDate.setDate(viewDate.getDate() + 7);
    if (currentView === 'today') viewDate.setDate(viewDate.getDate() + 1);
    renderCalendar(currentView);
  };

  // Initialize calendar
  renderCalendar('monthly');

  // Modern Charts with better styling
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false }
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#6B7280' }
      },
      y: {
        beginAtZero: true,
        grid: { color: '#F3F4F6' },
        ticks: { 
          color: '#6B7280',
          callback: value => '₱' + value.toLocaleString()
        }
      }
    }
  };

  // Daily Orders Chart
  new Chart(document.getElementById('dailyOrdersChart'), {
    type: 'bar',
    data: {
      labels: <?php echo json_encode($orderDates); ?>,
      datasets: [{
        label: 'Revenue (₱)',
        data: <?php echo json_encode($orderTotals); ?>,
        backgroundColor: '#3B82F6',
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: chartOptions
  });

  // Monthly Orders Chart
  new Chart(document.getElementById('monthlyOrdersChart'), {
    type: 'line',
    data: {
      labels: <?php echo json_encode($months); ?>,
      datasets: [{
        label: 'Monthly Revenue (₱)',
        data: <?php echo json_encode($monthlySalesTotals); ?>,
        borderColor: '#10B981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        fill: true,
        tension: 0.4,
        borderWidth: 3,
        pointBackgroundColor: '#10B981',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 6
      }]
    },
    options: {
      ...chartOptions,
      plugins: {
        ...chartOptions.plugins,
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          titleColor: '#fff',
          bodyColor: '#fff',
          borderColor: '#10B981',
          borderWidth: 1
        }
      }
    }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminBoard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\OneDrive\Desktop\Multi-branchVCMS\MBVCMS\resources\views/dashboard.blade.php ENDPATH**/ ?>